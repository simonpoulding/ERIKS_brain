OLED Libray for Piccolino. Uses 1K of local RAM. 
Feel free to modify/add features. you can send new commits to 
admin@wctek.com for inclusion in future releases.

Revision History
================
Version 1.0 - MAY 2015 : Initial Release
Version 1.1 - JUN 2015 : Minor fixes
Version 1.2 - JULY 2015: Added ::displayON, ::displayOFF & ::dim(ON|OFF) to turn display on/off or dimmed (useful for vehicle night driving)
Version 1.3 - JULY 2015: Added ::drawRect, GRAY flag (draws lines every sesond pixel)
