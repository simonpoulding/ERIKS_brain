-- The chip id is to register your piccolino with the piccolino.io gateway
-- it is used as your mailbox-id to relay inter-piccolino messaging.

print(node.chipid())
