Run this script to set the Piccolino in passive mode and enable communication to the ESP8266 WIFI module. 
Do not forget to press the DEVICE SELECT switch to enable the FTDI programmer to talk to the ESP module
directly.

During development, you may want to have this sketch in its own window on the side of your desktop 
to quickly switch between your sketch and the ESP8266 side LUAs.
