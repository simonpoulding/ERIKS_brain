Piccolino's WIFI library.

Feel free to modify it and add features. Please submitt any improvements to
admin@wctek.com for inclusion in future updates.

Currently supports communication with ESP8266 WIFI module and sets module
in either STATION or AP mode by running the appropriate script within your sketch.

Sep 22 2015: Updated to handle feeds from piccolino.io. You will need to upload
another lua script to the wifi module. The script is called picoFeed.lua and is
available on the GitHub page (github.com/wctek).

See the example folder for more information.
