These are the original (v1.0) distribution LUA scripts which are loaded by default in the Piccolino micro-controller.
Jul 15 2015: Added picoFeed.lua to enable data-feed transfer from piccolino.io to the Piccolino unit.
